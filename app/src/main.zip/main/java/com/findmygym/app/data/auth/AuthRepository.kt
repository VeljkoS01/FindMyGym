package com.findmygym.app.data.auth

import com.findmygym.app.data.model.AppUser
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import com.google.firebase.firestore.DocumentReference

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    fun isLoggedIn(): Boolean = auth.currentUser != null
    fun currentUid(): String? = auth.currentUser?.uid
    fun logout() = auth.signOut()

    suspend fun login(emailRaw: String, password: String) {
        val email = emailRaw.trim()
        if (email.isBlank()) throw Exception("Please enter your email")
        auth.signInWithEmailAndPassword(email, password).await()

        ensureUserDocExists()
    }

    suspend fun register(
        emailRaw: String,
        password: String,
        fullName: String,
        phone: String
    ) {
        val email = emailRaw.trim()

        if (email.isBlank()) throw Exception("Please enter your email")
        if (password.length < 6) throw Exception("Password must be at least 6 characters")
        if (fullName.trim().isBlank()) throw Exception("Please enter your full name")
        if (phone.trim().isBlank()) throw Exception("Please enter your phone number")

        val result = auth.createUserWithEmailAndPassword(email, password).await()
        val user = result.user ?: throw Exception("Error: no user")
        val uid = user.uid

        val profile = AppUser(
            uid = uid,
            email = email,
            fullName = fullName.trim(),
            phone = phone.trim(),
            points = 0
        )

        db.collection("users").document(uid).set(profile).await()
    }

    suspend fun getMyProfile(): AppUser? {
        val uid = currentUid() ?: return null
        val ref = db.collection("users").document(uid)
        val snap = ref.get().await()

        if (!snap.exists()) {
            val email = auth.currentUser?.email ?: ""
            val repaired = AppUser(
                uid = uid,
                email = email,
                fullName = "",
                phone = "",
                points = 0
            )
            ref.set(repaired, SetOptions.merge()).await()
            return repaired
        }

        return snap.toObject(AppUser::class.java)
    }

    suspend fun updateMyLocation(lat: Double, lng: Double) {
        val uid = currentUid() ?: return
        db.collection("users").document(uid).set(
            mapOf(
                "lastLat" to lat,
                "lastLng" to lng,
                "lastLocationAt" to System.currentTimeMillis()
            ),
            SetOptions.merge()
        ).await()
    }

    suspend fun reauthenticateWithPassword(password: String) {
        val user = auth.currentUser ?: throw Exception("Not logged in")
        val email = user.email ?: throw Exception("No email for current user")
        val cred = EmailAuthProvider.getCredential(email, password)
        user.reauthenticate(cred).await()
    }

    suspend fun deleteAccountAndData() {
        val user = auth.currentUser ?: throw Exception("Not logged in")
        val uid = user.uid

        suspend fun deleteRefsInBatches(refs: List<DocumentReference>) {
            val chunkSize = 450 // safe ispod 500
            var i = 0
            while (i < refs.size) {
                val batch = db.batch()
                val end = minOf(i + chunkSize, refs.size)
                for (j in i until end) batch.delete(refs[j])
                batch.commit().await()
                i = end
            }
        }

        // 1) obrisi moje ratings (svuda)
        try {
            val ratingRefs = db.collectionGroup("ratings")
                .whereEqualTo("authorUid", uid)
                .get().await()
                .documents
                .map { it.reference }

            deleteRefsInBatches(ratingRefs)
        } catch (e: Exception) {
            throw Exception("Delete failed at: my ratings. ${e.message}")
        }

        // 2) obrisi moje comments (svuda)
        try {
            val commentRefs = db.collectionGroup("comments")
                .whereEqualTo("authorUid", uid)
                .get().await()
                .documents
                .map { it.reference }

            deleteRefsInBatches(commentRefs)
        } catch (e: Exception) {
            throw Exception("Delete failed at: my comments. ${e.message}")
        }

        // 3) obrisi moje gyms (i njihove subkolekcije)
        try {
            val gymsSnap = db.collection("gyms")
                .whereEqualTo("authorUid", uid)
                .get().await()

            for (doc in gymsSnap.documents) {
                val gymRef = doc.reference

                // ratings u mom gym-u (od drugih usera)
                val ratings = gymRef.collection("ratings").get().await()
                for (r in ratings.documents) {
                    r.reference.delete().await()
                }

                // comments u mom gym-u
                val comments = gymRef.collection("comments").get().await()
                for (c in comments.documents) {
                    c.reference.delete().await()
                }

                gymRef.delete().await()
            }
        } catch (e: Exception) {
            throw Exception("Delete failed at: my gyms cleanup. ${e.message}")
        }

        // 4) user doc
        try {
            db.collection("users").document(uid).delete().await()
        } catch (e: Exception) {
            throw Exception("Delete failed at: user doc. ${e.message}")
        }

        // 5) auth user (reauth vec radiš u UI)
        try {
            user.delete().await()
        } catch (e: Exception) {
            throw Exception("Delete failed at: auth user. ${e.message}")
        }
    }


    private suspend fun ensureUserDocExists() {
        val uid = currentUid() ?: return
        val ref = db.collection("users").document(uid)
        val snap = ref.get().await()
        if (snap.exists()) return

        val email = auth.currentUser?.email ?: ""
        val repaired = AppUser(
            uid = uid,
            email = email,
            fullName = "",
            phone = "",
            points = 0
        )
        ref.set(repaired, SetOptions.merge()).await()
    }
}
